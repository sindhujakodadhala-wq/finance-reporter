"""Menu-driven terminal interface."""
from . import analytics, config, importer, reports, plotting
from .models import INCOME, EXPENSE
from .storage import TransactionStore
from .ui import banner, color, money, paginate, table
from .validation import (ask, ask_menu_choice, confirm, validate_amount, validate_category,
                         validate_date, validate_description, validate_type, ValidationError)

MENU = """
  1) Add transaction
  2) View all transactions
  3) Search / filter
  4) Executive summary
  5) Warnings & alerts
  6) Import CSV file
  7) Export reports (Markdown / TXT / CSV)
  8) Generate charts (PNG)
  9) Delete transaction
  0) Exit
"""


def tx_table(rows):
    return table(["ID", "Date", "Type", "Category", "Description", "Amount"],
                 [[t.id, t.date, t.type, t.category, t.description,
                   ("+" if t.type == INCOME else "-") + f"{t.amount:,.2f}"] for t in rows],
                 [4, 10, 7, 16, 30, 13], right=(0, 5))


class App:
    def __init__(self, store: TransactionStore, input_fn=input, output_fn=print):
        self.store = store
        self.inp = input_fn
        self.out = output_fn

    # ----- actions -----
    def add(self):
        self.out(color("\nAdd transaction (Ctrl+C to cancel)", "bold"))
        try:
            date = ask("Date (YYYY-MM-DD)", validate_date, input_fn=self.inp, output_fn=self.out)
            type_ = ask("Type (income/expense)", validate_type, input_fn=self.inp, output_fn=self.out)
            amount = ask("Amount", validate_amount, input_fn=self.inp, output_fn=self.out)
            category = ask("Category", validate_category, input_fn=self.inp, output_fn=self.out)
            desc = ask("Description", validate_description, input_fn=self.inp, output_fn=self.out)
        except KeyboardInterrupt:
            self.out("\n  Cancelled.")
            return
        tx = self.store.add(date, desc, category, type_, amount)
        self.out(color(f"  ✓ Saved #{tx.id}: {tx.date} {tx.type} {money(tx.amount)} [{tx.category}]", "green"))

    def view(self):
        rows = sorted(self.store.transactions, key=lambda t: (t.date, t.id))
        paginate(rows, tx_table, input_fn=self.inp, output_fn=self.out)

    def search(self):
        self.out(color("\nSearch / filter (leave blank to skip a filter)", "bold"))
        kw = self.inp("Keyword (description or category): ").strip() or None
        cat = self.inp("Exact category: ").strip() or None
        raw_type = self.inp("Type (income/expense): ").strip()
        type_ = None
        if raw_type:
            try:
                type_ = validate_type(raw_type)
            except ValidationError as e:
                self.out(f"  ✗ {e} - ignoring type filter.")
        start = end = None
        for label in ("From date", "To date"):
            raw = self.inp(f"{label} (YYYY-MM-DD): ").strip()
            if raw:
                try:
                    val = validate_date(raw)
                    if label == "From date":
                        start = val
                    else:
                        end = val
                except ValidationError as e:
                    self.out(f"  ✗ {e} - ignoring.")
        res = analytics.search(self.store.transactions, kw, cat, type_, start, end)
        paginate(res, tx_table, input_fn=self.inp, output_fn=self.out)
        if res:
            inc = sum(t.amount for t in res if t.type == INCOME)
            exp = sum(t.amount for t in res if t.type == EXPENSE)
            self.out(f"Matches: income {money(inc)} · expenses {money(exp)} · net {money(inc - exp)}")

    def summary(self):
        txs = self.store.transactions
        self.out("\n" + reports.render_summary(txs, analytics.find_warnings(txs)))

    def warnings(self):
        warns = analytics.find_warnings(self.store.transactions)
        if not warns:
            self.out(color("\n  ✓ No warnings. Everything looks fine.", "green"))
            return
        self.out(color(f"\n⚠ {len(warns)} warning(s):", "yellow"))
        for w in warns:
            self.out(f"  • {w}")

    def import_file(self):
        path = self.inp("\nPath to CSV file (blank to cancel): ").strip().strip('"').strip("'")
        if not path:
            return
        res = importer.import_csv(path, self.store)
        if res.fatal:
            self.out(color(f"  ✗ {res.fatal}", "red"))
            return
        self.out(f"  Rows read: {res.total_rows} · valid: {len(res.added)} · "
                 f"errors: {len(res.errors)} · duplicates skipped: {res.duplicates}")
        for line, msg in res.errors[:10]:
            self.out(color(f"    line {line}: {msg}", "red"))
        if len(res.errors) > 10:
            self.out(f"    ... and {len(res.errors) - 10} more (see {config.IMPORT_LOG_PATH.name})")
        if res.errors:
            importer.write_error_log(res, path, config.IMPORT_LOG_PATH)
        if res.added and confirm(f"Import {len(res.added)} valid row(s)?", self.inp):
            self.store.add_many(res.added)
            self.out(color(f"  ✓ Imported {len(res.added)} transaction(s).", "green"))

    def export(self):
        if not self.store.transactions:
            self.out("  Nothing to export.")
            return
        for p in reports.export_all(self.store.transactions):
            self.out(color(f"  ✓ Wrote {p}", "green"))

    def charts(self):
        if not self.store.transactions:
            self.out("  Nothing to plot.")
            return
        try:
            for p in plotting.generate_charts(self.store.transactions):
                self.out(color(f"  ✓ Wrote {p}", "green"))
        except ImportError:
            self.out(color("  ✗ matplotlib is not installed. Run: pip install matplotlib", "red"))

    def delete(self):
        raw = self.inp("\nTransaction ID to delete (blank to cancel): ").strip()
        if not raw:
            return
        if not raw.isdigit():
            self.out("  ✗ ID must be a whole number.")
            return
        tx = next((t for t in self.store.transactions if t.id == int(raw)), None)
        if tx is None:
            self.out(f"  ✗ No transaction with ID {raw}.")
        elif confirm(f"Delete #{tx.id} {tx.date} {tx.description} {money(tx.amount)}?", self.inp):
            self.store.delete(tx.id)
            self.out(color("  ✓ Deleted.", "green"))

    # ----- main loop -----
    def run(self):
        self.out(banner("PERSONAL FINANCE CSV REPORTER", "load · validate · summarise · visualise"))
        for note in self.store.load_notes:
            self.out(color(f"  ℹ {note}", "yellow"))
        self.out(f"  {len(self.store.transactions)} transaction(s) loaded.")
        actions = {"1": self.add, "2": self.view, "3": self.search, "4": self.summary,
                   "5": self.warnings, "6": self.import_file, "7": self.export,
                   "8": self.charts, "9": self.delete}
        while True:
            self.out(MENU)
            try:
                choice = ask_menu_choice("Choose an option: ", set(actions) | {"0", "q"},
                                         input_fn=self.inp, output_fn=self.out)
                if choice in ("0", "q"):
                    self.out("Goodbye! Your data is saved.")
                    return
                actions[choice]()
            except (KeyboardInterrupt, EOFError):
                self.out("\nGoodbye! Your data is saved.")
                return
