"""Business logic: filtering, summaries, trends, warnings."""
from collections import defaultdict
from statistics import mean, median
from typing import List, Optional

from . import config
from .models import Transaction, INCOME, EXPENSE


def search(txs: List[Transaction], keyword: Optional[str] = None, category: Optional[str] = None,
           type_: Optional[str] = None, start: Optional[str] = None, end: Optional[str] = None,
           min_amount: Optional[float] = None, max_amount: Optional[float] = None) -> List[Transaction]:
    kw = keyword.lower().strip() if keyword else None
    cat = category.lower().strip() if category else None
    out = []
    for t in txs:
        if kw and kw not in t.description.lower() and kw not in t.category.lower():
            continue
        if cat and cat != t.category.lower():
            continue
        if type_ and t.type != type_:
            continue
        if start and t.date < start:
            continue
        if end and t.date > end:
            continue
        if min_amount is not None and t.amount < min_amount:
            continue
        if max_amount is not None and t.amount > max_amount:
            continue
        out.append(t)
    return sorted(out, key=lambda t: (t.date, t.id))


def category_totals(txs: List[Transaction], type_: str) -> dict:
    totals = defaultdict(float)
    for t in txs:
        if t.type == type_:
            totals[t.category] += t.amount
    return {k: round(v, 2) for k, v in sorted(totals.items(), key=lambda kv: kv[1], reverse=True)}


def monthly_breakdown(txs: List[Transaction]) -> list:
    """[(YYYY-MM, income, expense, net)] sorted chronologically."""
    inc, exp = defaultdict(float), defaultdict(float)
    for t in txs:
        (inc if t.type == INCOME else exp)[t.month] += t.amount
    months = sorted(set(inc) | set(exp))
    return [(m, round(inc[m], 2), round(exp[m], 2), round(inc[m] - exp[m], 2)) for m in months]


def summarize(txs: List[Transaction]) -> dict:
    incomes = [t.amount for t in txs if t.type == INCOME]
    expenses = [t.amount for t in txs if t.type == EXPENSE]
    total_in, total_out = sum(incomes), sum(expenses)
    monthly = monthly_breakdown(txs)
    n_months = max(len(monthly), 1)
    savings_rate = (total_in - total_out) / total_in * 100 if total_in else 0.0

    trend = "n/a"
    if len(monthly) >= 2 and monthly[-2][2]:
        prev, last = monthly[-2][2], monthly[-1][2]
        change = (last - prev) / prev * 100
        word = "up" if change > 0 else "down" if change < 0 else "flat"
        trend = f"expenses {word} {abs(change):.1f}% vs previous month"
    exp_cats = category_totals(txs, EXPENSE)
    status = "No data"
    if txs:
        status = ("Healthy" if savings_rate >= config.LOW_SAVINGS_RATE
                  else "Tight" if total_in >= total_out else "Deficit")
    dates = [t.date for t in txs]
    return {
        "count": len(txs),
        "income_count": len(incomes),
        "expense_count": len(expenses),
        "total_income": round(total_in, 2),
        "total_expense": round(total_out, 2),
        "net": round(total_in - total_out, 2),
        "savings_rate": round(savings_rate, 1),
        "avg_income": round(mean(incomes), 2) if incomes else 0.0,
        "avg_expense": round(mean(expenses), 2) if expenses else 0.0,
        "avg_monthly_income": round(total_in / n_months, 2),
        "avg_monthly_expense": round(total_out / n_months, 2),
        "largest_expense": max((t for t in txs if t.type == EXPENSE), key=lambda t: t.amount, default=None),
        "top_expense_category": next(iter(exp_cats), None),
        "expense_by_category": exp_cats,
        "income_by_category": category_totals(txs, INCOME),
        "monthly": monthly,
        "trend": trend,
        "status": status,
        "date_range": (min(dates), max(dates)) if dates else None,
    }


def find_warnings(txs: List[Transaction]) -> List[str]:
    """Threshold / anomaly indicators."""
    warns = []
    if not txs:
        return warns
    s = summarize(txs)

    for m, inc, exp, net in s["monthly"]:
        if exp > inc:
            warns.append(f"Overspending in {m}: expenses {exp:,.2f} exceed income {inc:,.2f}.")

    if s["total_income"] and s["savings_rate"] < config.LOW_SAVINGS_RATE:
        warns.append(f"Low savings rate: {s['savings_rate']:.1f}% (target >= {config.LOW_SAVINGS_RATE:.0f}%).")

    total_exp = s["total_expense"]
    for cat, amt in s["expense_by_category"].items():
        share = amt / total_exp * 100 if total_exp else 0
        if share > config.CATEGORY_SHARE_LIMIT:
            warns.append(f"Category '{cat}' is {share:.1f}% of all spending (limit {config.CATEGORY_SHARE_LIMIT:.0f}%).")

    by_cat = defaultdict(list)
    for t in txs:
        if t.type == EXPENSE:
            by_cat[t.category].append(t)
    for cat, items in by_cat.items():
        if len(items) < config.ANOMALY_MIN_SAMPLES:
            continue
        med = median(i.amount for i in items)
        for i in items:
            if i.amount > config.ANOMALY_FACTOR * med:
                warns.append(f"Unusual expense #{i.id} on {i.date}: '{i.description}' {i.amount:,.2f} "
                             f"is {i.amount / med:.1f}x the typical {cat} expense ({med:,.2f}).")

    seen = defaultdict(list)
    for t in txs:
        seen[(t.date, t.description.lower(), t.type, t.amount)].append(t.id)
    for key, ids in seen.items():
        if len(ids) > 1:
            warns.append(f"Possible duplicate entries {ids}: '{key[1]}' on {key[0]}.")
    return warns
