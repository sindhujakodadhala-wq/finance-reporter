"""Terminal helpers: ANSI colour, fixed-width tables, pagination."""
import shutil
from typing import List, Sequence

from . import config

_CODES = {"red": "31", "green": "32", "yellow": "33", "blue": "34", "cyan": "36", "bold": "1", "dim": "2"}


def color(text: str, name: str) -> str:
    if not config.USE_COLOR:
        return text
    return f"\033[{_CODES[name]}m{text}\033[0m"


def money(x: float) -> str:
    return f"{config.CURRENCY}{x:,.2f}"


def trunc(text: str, width: int) -> str:
    return text if len(text) <= width else text[: width - 1] + "…"


def table(headers: Sequence[str], rows: List[Sequence], widths: Sequence[int], right: Sequence[int] = ()) -> str:
    """Fixed-width table. `right` = indexes of right-aligned columns."""
    def fmt(cells):
        out = []
        for i, (c, w) in enumerate(zip(cells, widths)):
            c = trunc(str(c), w)
            out.append(c.rjust(w) if i in right else c.ljust(w))
        return " | ".join(out)
    line = "-+-".join("-" * w for w in widths)
    return "\n".join([fmt(headers), line] + [fmt(r) for r in rows])


def banner(title: str, subtitle: str = "") -> str:
    width = max(len(title), len(subtitle)) + 6
    top = "═" * width
    lines = [color(top, "cyan"), color(title.center(width), "bold")]
    if subtitle:
        lines.append(color(subtitle.center(width), "dim"))
    lines.append(color(top, "cyan"))
    return "\n".join(lines)


def bar(value: float, maximum: float, width: int = 24) -> str:
    n = int(round(width * value / maximum)) if maximum else 0
    return "█" * n


def paginate(rows: List, render, page_size: int = config.PAGE_SIZE, input_fn=input, output_fn=print) -> None:
    """Show `rows` page by page. `render(page_rows)` returns a printable string."""
    if not rows:
        output_fn("  (no records)")
        return
    pages = (len(rows) + page_size - 1) // page_size
    page = 0
    while True:
        chunk = rows[page * page_size:(page + 1) * page_size]
        output_fn(render(chunk))
        output_fn(color(f"Page {page + 1}/{pages} · {len(rows)} record(s)", "dim"))
        if pages == 1:
            return
        nav = input_fn("[n]ext  [p]revious  [q]uit: ").strip().lower()
        if nav in ("n", "") and page < pages - 1:
            page += 1
        elif nav == "p" and page > 0:
            page -= 1
        elif nav == "q":
            return
