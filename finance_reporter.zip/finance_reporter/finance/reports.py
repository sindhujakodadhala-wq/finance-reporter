"""Report rendering and export (text, Markdown, CSV)."""
import csv
from datetime import datetime
from pathlib import Path
from typing import List

from . import analytics, config
from .models import Transaction
from .ui import bar, color, money, table


def render_summary(txs: List[Transaction], warnings: List[str] = None, colour: bool = True) -> str:
    s = analytics.summarize(txs)
    if not s["count"]:
        return "No transactions to summarise."
    paint = color if colour else (lambda t, _n: t)
    lines = []
    lines.append(paint("EXECUTIVE SUMMARY", "bold"))
    lines.append(f"Period : {s['date_range'][0]} to {s['date_range'][1]}   ({s['count']} transactions)")
    lines.append(f"Status : {s['status']}   |   Trend: {s['trend']}")
    lines.append("")
    lines.append(table(["Metric", "Value"], [
        ["Total income", money(s["total_income"])],
        ["Total expenses", money(s["total_expense"])],
        ["Net balance", money(s["net"])],
        ["Savings rate", f"{s['savings_rate']:.1f}%"],
        ["Avg income / txn", money(s["avg_income"])],
        ["Avg expense / txn", money(s["avg_expense"])],
        ["Avg monthly income", money(s["avg_monthly_income"])],
        ["Avg monthly expense", money(s["avg_monthly_expense"])],
        ["Top expense category", s["top_expense_category"] or "-"],
        ["Largest expense", (f"{money(s['largest_expense'].amount)} ({s['largest_expense'].description})"
                             if s["largest_expense"] else "-")],
    ], [22, 44], right=()))
    lines.append("")
    lines.append(paint("Spending by category", "bold"))
    top = max(s["expense_by_category"].values(), default=0)
    total = s["total_expense"] or 1
    lines.append(table(["Category", "Amount", "Share", ""], [
        [c, money(a), f"{a / total * 100:.1f}%", bar(a, top)] for c, a in s["expense_by_category"].items()
    ], [18, 14, 7, 24], right=(1, 2)))
    lines.append("")
    lines.append(paint("Monthly trend", "bold"))
    lines.append(table(["Month", "Income", "Expenses", "Net"], [
        [m, money(i), money(e), money(n)] for m, i, e, n in s["monthly"]
    ], [8, 14, 14, 14], right=(1, 2, 3)))
    if warnings:
        lines.append("")
        lines.append(paint(f"⚠ WARNINGS ({len(warnings)})", "yellow"))
        lines += [f"  • {w}" for w in warnings]
    return "\n".join(lines)


def to_markdown(txs: List[Transaction]) -> str:
    s = analytics.summarize(txs)
    cur = config.CURRENCY
    out = [f"# Personal Finance Report", f"_Generated {datetime.now():%Y-%m-%d %H:%M}_", ""]
    if not s["count"]:
        return "\n".join(out + ["No transactions."])
    out += [f"**Period:** {s['date_range'][0]} to {s['date_range'][1]} · **Transactions:** {s['count']}", "",
            "## Key metrics", "| Metric | Value |", "|---|---:|",
            f"| Total income | {cur}{s['total_income']:,.2f} |",
            f"| Total expenses | {cur}{s['total_expense']:,.2f} |",
            f"| Net balance | {cur}{s['net']:,.2f} |",
            f"| Savings rate | {s['savings_rate']:.1f}% |",
            f"| Status | {s['status']} |",
            f"| Trend | {s['trend']} |", "",
            "## Spending by category", "| Category | Amount | Share |", "|---|---:|---:|"]
    total = s["total_expense"] or 1
    out += [f"| {c} | {cur}{a:,.2f} | {a / total * 100:.1f}% |" for c, a in s["expense_by_category"].items()]
    out += ["", "## Monthly breakdown", "| Month | Income | Expenses | Net |", "|---|---:|---:|---:|"]
    out += [f"| {m} | {cur}{i:,.2f} | {cur}{e:,.2f} | {cur}{n:,.2f} |" for m, i, e, n in s["monthly"]]
    warns = analytics.find_warnings(txs)
    out += ["", "## Warnings"] + ([f"- {w}" for w in warns] or ["- None"])
    return "\n".join(out) + "\n"


def to_audit_text(txs: List[Transaction]) -> str:
    header = f"AUDIT LOG - generated {datetime.now():%Y-%m-%d %H:%M:%S} - {len(txs)} records\n"
    body = render_summary(txs, analytics.find_warnings(txs), colour=False)
    rows = table(["ID", "Date", "Type", "Category", "Description", "Amount"],
                 [[t.id, t.date, t.type, t.category, t.description, f"{t.amount:,.2f}"]
                  for t in sorted(txs, key=lambda t: (t.date, t.id))],
                 [4, 10, 7, 16, 32, 12], right=(5,))
    return f"{header}\n{body}\n\nTRANSACTIONS\n{rows}\n"


def export_all(txs: List[Transaction], out_dir=None) -> List[Path]:
    """Write Markdown, text audit log and CSV summary. Returns paths."""
    out_dir = Path(out_dir or config.REPORTS_DIR)
    out_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    md, txt, csv_path = (out_dir / f"report_{stamp}.md", out_dir / f"audit_{stamp}.txt",
                         out_dir / f"summary_{stamp}.csv")
    md.write_text(to_markdown(txs), encoding="utf-8")
    txt.write_text(to_audit_text(txs), encoding="utf-8")
    s = analytics.summarize(txs)
    with open(csv_path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["section", "key", "income", "expense", "net"])
        for m, i, e, n in s["monthly"]:
            w.writerow(["month", m, i, e, n])
        for c, a in s["expense_by_category"].items():
            w.writerow(["expense_category", c, "", a, -a])
        for c, a in s["income_by_category"].items():
            w.writerow(["income_category", c, a, "", a])
        w.writerow(["total", "all", s["total_income"], s["total_expense"], s["net"]])
    return [md, txt, csv_path]
