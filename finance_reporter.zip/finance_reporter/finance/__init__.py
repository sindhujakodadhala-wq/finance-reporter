"""Personal Finance CSV Reporter."""
__version__ = "1.0.0"
