"""Central configuration (paths, limits, thresholds)."""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
REPORTS_DIR = BASE_DIR / "reports"
STORE_PATH = DATA_DIR / "transactions.json"
IMPORT_LOG_PATH = DATA_DIR / "import_errors.log"

CURRENCY = os.environ.get("FINANCE_CURRENCY", "$")
USE_COLOR = os.environ.get("NO_COLOR") is None

# Validation limits
MIN_AMOUNT = 0.01
MAX_AMOUNT = 10_000_000.00
MAX_DESC_LEN = 80
MAX_CAT_LEN = 30
MIN_YEAR, MAX_YEAR = 2000, 2100

# Warning thresholds
LOW_SAVINGS_RATE = 10.0        # % of income
CATEGORY_SHARE_LIMIT = 40.0    # % of total expenses
ANOMALY_FACTOR = 2.5           # x category median
ANOMALY_MIN_SAMPLES = 4        # min expenses in a category before judging

PAGE_SIZE = 15
