"""Bulk CSV import with row-by-row error logging."""
import csv
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import List, Tuple

from .models import Transaction, INCOME, EXPENSE
from .validation import (ValidationError, validate_date, validate_amount, validate_type,
                         validate_category, validate_description)

REQUIRED = {"date", "amount"}


@dataclass
class ImportResult:
    added: List[Transaction] = field(default_factory=list)
    errors: List[Tuple[int, str]] = field(default_factory=list)   # (line number, message)
    duplicates: int = 0
    total_rows: int = 0
    fatal: str = ""


def _parse_row(row: dict) -> Transaction:
    raw_amount = str(row.get("amount") or "").strip()
    negative = raw_amount.startswith("-") or (raw_amount.startswith("(") and raw_amount.endswith(")"))
    raw_amount = raw_amount.strip("()").lstrip("-")
    amount = validate_amount(raw_amount)

    raw_type = str(row.get("type") or "").strip()
    if raw_type and negative:
        raise ValidationError("Negative amount not allowed when a type column is given.")
    type_ = validate_type(raw_type) if raw_type else (EXPENSE if negative else INCOME)
    return Transaction(
        id=0,
        date=validate_date(row.get("date") or ""),
        description=validate_description(row.get("description") or row.get("memo") or "(no description)"),
        category=validate_category(row.get("category") or "Uncategorized"),
        type=type_,
        amount=amount,
    )


def import_csv(path, store=None) -> ImportResult:
    """Parse `path` into an ImportResult. Does NOT write to the store."""
    result = ImportResult()
    path = Path(path).expanduser()
    try:
        fh = open(path, "r", encoding="utf-8-sig", newline="")
    except FileNotFoundError:
        result.fatal = f"File not found: {path}"
        return result
    except OSError as exc:
        result.fatal = f"Cannot open file: {exc}"
        return result

    with fh:
        try:
            sample = fh.read(2048)
            fh.seek(0)
            try:
                dialect = csv.Sniffer().sniff(sample, delimiters=",;\t")
            except csv.Error:
                dialect = csv.excel
            reader = csv.DictReader(fh, dialect=dialect)
            if not reader.fieldnames:
                result.fatal = "File is empty."
                return result
            reader.fieldnames = [(n or "").strip().lower() for n in reader.fieldnames]
            missing = REQUIRED - set(reader.fieldnames)
            if missing:
                result.fatal = (f"Missing required column(s): {', '.join(sorted(missing))}. "
                                f"Found: {', '.join(reader.fieldnames)}")
                return result

            seen = set()
            for row in reader:
                line = reader.line_num
                if not any((v or "").strip() for v in row.values() if not isinstance(v, list)):
                    continue  # blank line
                result.total_rows += 1
                if None in row:  # more cells than headers
                    result.errors.append((line, "Too many columns in row."))
                    continue
                try:
                    tx = _parse_row(row)
                except ValidationError as exc:
                    result.errors.append((line, str(exc)))
                    continue
                key = (tx.date, tx.description.lower(), tx.type, tx.amount)
                if key in seen or (store is not None and store.is_duplicate(tx)):
                    result.duplicates += 1
                    continue
                seen.add(key)
                result.added.append(tx)
        except (csv.Error, UnicodeDecodeError) as exc:
            result.fatal = f"Could not parse file: {exc}"
    return result


def write_error_log(result: ImportResult, source: str, log_path) -> None:
    log_path = Path(log_path)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with open(log_path, "a", encoding="utf-8") as fh:
        fh.write(f"=== {datetime.now():%Y-%m-%d %H:%M:%S} | {source} | "
                 f"rows={result.total_rows} ok={len(result.added)} "
                 f"errors={len(result.errors)} duplicates={result.duplicates} ===\n")
        for line, msg in result.errors:
            fh.write(f"line {line}: {msg}\n")
