"""Core data structures."""
from dataclasses import dataclass, asdict

INCOME = "income"
EXPENSE = "expense"
TYPES = (INCOME, EXPENSE)


@dataclass
class Transaction:
    id: int
    date: str          # ISO format YYYY-MM-DD
    description: str
    category: str
    type: str          # "income" | "expense"
    amount: float      # always positive; sign comes from `type`

    @property
    def signed(self) -> float:
        return self.amount if self.type == INCOME else -self.amount

    @property
    def month(self) -> str:
        return self.date[:7]

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "Transaction":
        """Build from a dict, re-validating every field (raises ValidationError)."""
        from .validation import (validate_date, validate_amount, validate_type,
                                 validate_category, validate_description)
        return cls(
            id=int(d["id"]),
            date=validate_date(d["date"]),
            description=validate_description(d["description"]),
            category=validate_category(d["category"]),
            type=validate_type(d["type"]),
            amount=validate_amount(d["amount"]),
        )
