"""JSON persistence with corruption recovery and atomic writes."""
import json
import os
import shutil
from datetime import datetime
from pathlib import Path
from typing import List

from .models import Transaction
from .validation import ValidationError

SCHEMA_VERSION = 1


class TransactionStore:
    def __init__(self, path):
        self.path = Path(path)
        self.transactions: List[Transaction] = []
        self.load_notes: List[str] = []   # recovery messages, shown at startup

    # ---- load ----
    def load(self) -> List[Transaction]:
        self.load_notes = []
        self.transactions = []
        try:
            with open(self.path, "r", encoding="utf-8") as fh:
                payload = json.load(fh)
            records = payload["transactions"] if isinstance(payload, dict) else payload
            if not isinstance(records, list):
                raise ValueError("'transactions' must be a list")
        except FileNotFoundError:
            self.load_notes.append(f"No data file found. Created a new one at {self.path.name}.")
            self.save()
            return self.transactions
        except (json.JSONDecodeError, KeyError, ValueError, UnicodeDecodeError) as exc:
            backup = self.path.with_suffix(f".corrupt-{datetime.now():%Y%m%d%H%M%S}.json")
            try:
                shutil.copy2(self.path, backup)
                self.load_notes.append(f"Data file was unreadable ({exc}). Backed up to {backup.name}; starting fresh.")
            except OSError:
                self.load_notes.append(f"Data file was unreadable ({exc}); starting fresh.")
            self.save()
            return self.transactions

        skipped = 0
        seen_ids = set()
        for rec in records:
            try:
                tx = Transaction.from_dict(rec)
                if tx.id in seen_ids:
                    raise ValidationError("duplicate id")
            except (ValidationError, KeyError, TypeError, ValueError):
                skipped += 1
                continue
            seen_ids.add(tx.id)
            self.transactions.append(tx)
        if skipped:
            self.load_notes.append(f"Skipped {skipped} invalid record(s) while loading.")
        return self.transactions

    # ---- save ----
    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = {"schema_version": SCHEMA_VERSION,
                   "transactions": [t.to_dict() for t in self.transactions]}
        tmp = self.path.with_suffix(".tmp")
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(payload, fh, indent=2, ensure_ascii=False)
        os.replace(tmp, self.path)  # atomic: never leaves a half-written file

    # ---- mutations ----
    def next_id(self) -> int:
        return max((t.id for t in self.transactions), default=0) + 1

    def add(self, date, description, category, type_, amount) -> Transaction:
        tx = Transaction(self.next_id(), date, description, category, type_, amount)
        self.transactions.append(tx)
        self.save()
        return tx

    def add_many(self, txs: List[Transaction]) -> None:
        for tx in txs:
            tx.id = self.next_id()
            self.transactions.append(tx)
        self.save()

    def delete(self, tx_id: int) -> bool:
        before = len(self.transactions)
        self.transactions = [t for t in self.transactions if t.id != tx_id]
        if len(self.transactions) != before:
            self.save()
            return True
        return False

    def is_duplicate(self, tx: Transaction) -> bool:
        return any((t.date, t.description.lower(), t.type, t.amount) ==
                   (tx.date, tx.description.lower(), tx.type, tx.amount)
                   for t in self.transactions)
