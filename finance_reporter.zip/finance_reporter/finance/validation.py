"""Defensive validation: pure validators + loop-until-valid prompt helpers."""
import re
from datetime import datetime
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP

from . import config
from .models import INCOME, EXPENSE


class ValidationError(ValueError):
    """Raised when a value fails a domain check."""


_DATE_FORMATS = ("%Y-%m-%d", "%d-%m-%Y", "%d/%m/%Y", "%Y/%m/%d")


def validate_date(value) -> str:
    text = str(value).strip()
    if not text:
        raise ValidationError("Date is required (use YYYY-MM-DD).")
    for fmt in _DATE_FORMATS:
        try:
            d = datetime.strptime(text, fmt)
        except ValueError:
            continue
        if not config.MIN_YEAR <= d.year <= config.MAX_YEAR:
            raise ValidationError(f"Year must be between {config.MIN_YEAR} and {config.MAX_YEAR}.")
        return d.strftime("%Y-%m-%d")
    raise ValidationError(f"'{text}' is not a valid date. Use YYYY-MM-DD (e.g. 2026-03-15).")


def validate_amount(value) -> float:
    raw = str(value).strip()
    if not raw:
        raise ValidationError("Amount is required.")
    text = re.sub(r"[,\s]", "", raw)
    text = re.sub(r"^[^\d.+-]+|[^\d.]+$", "", text)  # strip currency symbols
    if not re.search(r"\d", text):
        raise ValidationError(f"'{raw}' is not a number.")
    try:
        num = Decimal(text)
    except InvalidOperation:
        raise ValidationError(f"'{value}' is not a number.")
    if not num.is_finite():
        raise ValidationError("Amount must be a finite number.")
    if num <= 0:
        raise ValidationError("Amount must be greater than zero (use the type to mark income/expense).")
    num = num.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    if num < Decimal(str(config.MIN_AMOUNT)):
        raise ValidationError(f"Amount must be at least {config.MIN_AMOUNT:.2f}.")
    if num > Decimal(str(config.MAX_AMOUNT)):
        raise ValidationError(f"Amount must not exceed {config.MAX_AMOUNT:,.2f}.")
    return float(num)


def validate_type(value) -> str:
    text = str(value).strip().lower()
    if text in ("i", "inc", "income", "credit", "cr"):
        return INCOME
    if text in ("e", "exp", "expense", "debit", "dr"):
        return EXPENSE
    raise ValidationError("Type must be 'income' or 'expense' (or i / e).")


def validate_category(value) -> str:
    text = " ".join(str(value).split())
    if not text:
        raise ValidationError("Category is required.")
    if len(text) > config.MAX_CAT_LEN:
        raise ValidationError(f"Category must be at most {config.MAX_CAT_LEN} characters.")
    if not re.fullmatch(r"[A-Za-z0-9 &/\-]+", text):
        raise ValidationError("Category may only contain letters, digits, spaces, & / -.")
    return text.title()


def validate_description(value) -> str:
    text = " ".join(re.sub(r"[\x00-\x1f\x7f]", " ", str(value)).split())
    if not text:
        raise ValidationError("Description is required.")
    if len(text) > config.MAX_DESC_LEN:
        raise ValidationError(f"Description must be at most {config.MAX_DESC_LEN} characters.")
    return text


# ----- interactive helpers -------------------------------------------------

def ask(prompt: str, validator, default=None, input_fn=input, output_fn=print):
    """Loop until `validator(raw)` succeeds. Blank input uses `default` if given."""
    while True:
        suffix = f" [{default}]" if default is not None else ""
        raw = input_fn(f"{prompt}{suffix}: ")
        if not raw.strip() and default is not None:
            raw = str(default)
        try:
            return validator(raw)
        except ValidationError as exc:
            output_fn(f"  ✗ {exc}")


def ask_menu_choice(prompt: str, valid: set, input_fn=input, output_fn=print) -> str:
    while True:
        raw = input_fn(prompt).strip().lower()
        if raw in valid:
            return raw
        output_fn(f"  ✗ Please choose one of: {', '.join(sorted(valid))}")


def confirm(prompt: str, input_fn=input) -> bool:
    return input_fn(f"{prompt} [y/N]: ").strip().lower() in ("y", "yes")
