"""Matplotlib charts. Degrades gracefully if matplotlib is not installed."""
from datetime import datetime
from pathlib import Path
from typing import List

from . import analytics, config
from .models import Transaction


def matplotlib_available() -> bool:
    try:
        import matplotlib  # noqa: F401
        return True
    except ImportError:
        return False


def generate_charts(txs: List[Transaction], out_dir=None) -> List[Path]:
    """Create three PNG charts. Raises ImportError if matplotlib is missing,
    ValueError if there is nothing to plot."""
    import matplotlib
    matplotlib.use("Agg")            # headless-safe; we save files rather than open windows
    import matplotlib.pyplot as plt

    if not txs:
        raise ValueError("No transactions to plot.")
    out_dir = Path(out_dir or config.REPORTS_DIR)
    out_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    s = analytics.summarize(txs)
    paths = []

    # 1. Monthly income vs expenses
    months = [m for m, *_ in s["monthly"]]
    inc = [i for _, i, _, _ in s["monthly"]]
    exp = [e for _, _, e, _ in s["monthly"]]
    fig, ax = plt.subplots(figsize=(9, 5))
    x = range(len(months))
    ax.bar([i - 0.2 for i in x], inc, width=0.4, label="Income", color="#2e8b57")
    ax.bar([i + 0.2 for i in x], exp, width=0.4, label="Expenses", color="#c0392b")
    ax.set_xticks(list(x))
    ax.set_xticklabels(months, rotation=30)
    ax.set_title("Monthly Income vs Expenses")
    ax.set_ylabel(f"Amount ({config.CURRENCY})")
    ax.legend()
    ax.grid(axis="y", alpha=0.3)
    fig.tight_layout()
    p = out_dir / f"chart_monthly_{stamp}.png"
    fig.savefig(p, dpi=130)
    plt.close(fig)
    paths.append(p)

    # 2. Expense distribution by category
    cats = s["expense_by_category"]
    if cats:
        fig, ax = plt.subplots(figsize=(7, 7))
        ax.pie(list(cats.values()), labels=list(cats.keys()), autopct="%1.1f%%", startangle=90)
        ax.set_title("Spending by Category")
        fig.tight_layout()
        p = out_dir / f"chart_categories_{stamp}.png"
        fig.savefig(p, dpi=130)
        plt.close(fig)
        paths.append(p)

    # 3. Cumulative balance over time
    ordered = sorted(txs, key=lambda t: (t.date, t.id))
    running, xs, ys = 0.0, [], []
    for t in ordered:
        running += t.signed
        xs.append(datetime.strptime(t.date, "%Y-%m-%d"))
        ys.append(running)
    fig, ax = plt.subplots(figsize=(9, 5))
    ax.plot(xs, ys, marker="o", markersize=3, color="#2c3e50")
    ax.axhline(0, color="grey", linewidth=0.8)
    ax.fill_between(xs, ys, 0, alpha=0.15)
    ax.set_title("Cumulative Balance")
    ax.set_ylabel(f"Balance ({config.CURRENCY})")
    fig.autofmt_xdate()
    ax.grid(alpha=0.3)
    fig.tight_layout()
    p = out_dir / f"chart_balance_{stamp}.png"
    fig.savefig(p, dpi=130)
    plt.close(fig)
    paths.append(p)
    return paths
