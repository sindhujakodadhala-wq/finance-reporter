"""Regenerate sample datasets in data/ (CSV, JSON and a deliberately messy import file)."""
import csv, json
from pathlib import Path

D = Path(__file__).resolve().parent.parent / "data"

# (date, description, category, type, amount)
rows = []
for m in range(7, 12):   # Jul..Nov 2026
    rows.append((f"2026-{m:02d}-01", "Monthly salary", "Salary", "income", 4200.00))
    rows.append((f"2026-{m:02d}-02", "Apartment rent", "Rent", "expense", 1250.00))
    rows.append((f"2026-{m:02d}-05", "Electricity & internet", "Utilities", "expense", 95.00 + m * 2.5))
    rows.append((f"2026-{m:02d}-09", "Supermarket", "Groceries", "expense", 120.00 + (m % 3) * 18.5))
    rows.append((f"2026-{m:02d}-16", "Supermarket", "Groceries", "expense", 98.40 + (m % 4) * 11.25))
    rows.append((f"2026-{m:02d}-20", "Restaurant dinner", "Dining", "expense", 42.00 + m * 3))
    rows.append((f"2026-{m:02d}-22", "Metro pass", "Transport", "expense", 35.00))
rows += [
    ("2026-07-14", "Freelance logo project", "Freelance", "income", 650.00),
    ("2026-09-18", "Freelance website", "Freelance", "income", 900.00),
    ("2026-08-11", "Streaming subscription", "Entertainment", "expense", 12.99),
    ("2026-10-11", "Streaming subscription", "Entertainment", "expense", 12.99),
    ("2026-09-03", "Cinema tickets", "Entertainment", "expense", 28.50),
    ("2026-10-27", "New laptop", "Shopping", "expense", 1850.00),            # anomaly
    ("2026-07-12", "Headphones", "Shopping", "expense", 59.90),
    ("2026-07-19", "Running shoes", "Shopping", "expense", 74.00),
    ("2026-09-25", "Backpack", "Shopping", "expense", 64.50),
    ("2026-11-08", "Phone case", "Shopping", "expense", 0.01 + 14.98),      # near-boundary small value
    ("2026-08-30", "Coffee", "Dining", "expense", 0.01),                     # boundary: minimum amount
]
rows.sort()
fields = ["date", "description", "category", "type", "amount"]
with open(D / "sample_transactions.csv", "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f); w.writerow(fields)
    for r in rows:
        w.writerow([*r[:4], f"{r[4]:.2f}"])
with open(D / "sample_transactions.json", "w", encoding="utf-8") as f:
    json.dump({"schema_version": 1, "transactions": [
        dict(id=i, date=r[0], description=r[1], category=r[2], type=r[3], amount=round(r[4], 2))
        for i, r in enumerate(rows, 1)]}, f, indent=2)

messy = """date,description,category,type,amount
2026-11-10,Valid grocery run,Groceries,expense,54.20
2026-13-45,Bad date row,Groceries,expense,20.00
2026-11-11,Negative amount,Dining,expense,-15.00
2026-11-12,Not a number,Dining,expense,abc
2026-11-13,,Transport,expense,12.00
12/11/2026,Alt date format ok,Transport,expense,"1,200.50"
2026-11-14,Bad type,Misc,transfer,10.00
2026-11-15,Zero amount,Misc,expense,0
2026-11-16,Too large,Misc,income,99999999
2026-11-17,Salary bonus,Salary,income,500.00
2026-11-17,Salary bonus,Salary,income,500.00
2026-11-18,Extra,Misc,expense,5,unexpected
"""
(D / "messy_import_demo.csv").write_text(messy, encoding="utf-8")
print(f"{len(rows)} sample rows written")
