import csv
import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from finance import analytics, importer, reports
from finance.cli import App
from finance.models import Transaction
from finance.storage import TransactionStore
from finance.validation import (ValidationError, validate_amount, validate_category,
                                validate_date, validate_type)

SAMPLE = Path(__file__).resolve().parent.parent / "data" / "sample_transactions.csv"
MESSY = Path(__file__).resolve().parent.parent / "data" / "messy_import_demo.csv"


def tx(i, d, cat, typ, amt, desc="x"):
    return Transaction(i, d, desc, cat, typ, amt)


class ValidationTests(unittest.TestCase):
    def test_dates(self):
        self.assertEqual(validate_date("2026-03-15"), "2026-03-15")
        self.assertEqual(validate_date("15/03/2026"), "2026-03-15")
        for bad in ("", "2026-02-30", "hello", "1999-01-01"):
            with self.assertRaises(ValidationError):
                validate_date(bad)

    def test_amounts(self):
        self.assertEqual(validate_amount("$1,234.567"), 1234.57)
        self.assertEqual(validate_amount("0.01"), 0.01)
        for bad in ("", "abc", "0", "-5", "nan", "inf", "10000000.01", "0.004"):
            with self.assertRaises(ValidationError):
                validate_amount(bad)

    def test_type_and_category(self):
        self.assertEqual(validate_type("E"), "expense")
        self.assertEqual(validate_category("  eating   out "), "Eating Out")
        with self.assertRaises(ValidationError):
            validate_type("transfer")
        with self.assertRaises(ValidationError):
            validate_category("bad<script>")


class StorageTests(unittest.TestCase):
    def setUp(self):
        self.dir = tempfile.TemporaryDirectory()
        self.path = Path(self.dir.name) / "t.json"

    def tearDown(self):
        self.dir.cleanup()

    def test_missing_file_created(self):
        s = TransactionStore(self.path)
        self.assertEqual(s.load(), [])
        self.assertTrue(self.path.exists())

    def test_roundtrip_persistence(self):
        s = TransactionStore(self.path); s.load()
        s.add("2026-01-01", "Pay", "Salary", "income", 100.0)
        s2 = TransactionStore(self.path); s2.load()
        self.assertEqual(len(s2.transactions), 1)
        self.assertEqual(s2.next_id(), 2)

    def test_corrupt_file_recovers(self):
        self.path.write_text("{not json", encoding="utf-8")
        s = TransactionStore(self.path)
        self.assertEqual(s.load(), [])
        self.assertTrue(s.load_notes)
        self.assertTrue(list(Path(self.dir.name).glob("*.corrupt-*.json")))

    def test_invalid_records_skipped(self):
        good = dict(id=1, date="2026-01-01", description="a", category="b", type="income", amount=5)
        bad = dict(id=2, date="nope", description="a", category="b", type="income", amount=5)
        self.path.write_text(json.dumps({"transactions": [good, bad]}), encoding="utf-8")
        s = TransactionStore(self.path)
        self.assertEqual(len(s.load()), 1)


class AnalyticsTests(unittest.TestCase):
    def test_summary_math(self):
        txs = [tx(1, "2026-01-01", "Salary", "income", 1000), tx(2, "2026-01-02", "Food", "expense", 250),
               tx(3, "2026-02-01", "Salary", "income", 1000), tx(4, "2026-02-02", "Food", "expense", 500)]
        s = analytics.summarize(txs)
        self.assertEqual(s["total_income"], 2000)
        self.assertEqual(s["net"], 1250)
        self.assertEqual(s["savings_rate"], 62.5)
        self.assertIn("up 100.0%", s["trend"])

    def test_empty(self):
        self.assertEqual(analytics.summarize([])["status"], "No data")
        self.assertEqual(analytics.find_warnings([]), [])

    def test_search(self):
        txs = [tx(1, "2026-01-01", "Food", "expense", 5, "Pizza"), tx(2, "2026-02-01", "Salary", "income", 9, "Pay")]
        self.assertEqual(len(analytics.search(txs, keyword="piz")), 1)
        self.assertEqual(len(analytics.search(txs, category="salary")), 1)
        self.assertEqual(len(analytics.search(txs, start="2026-01-15")), 1)

    def test_anomaly_and_overspend(self):
        txs = [tx(i, f"2026-01-{i:02d}", "Shop", "expense", 50) for i in range(1, 5)]
        txs.append(tx(9, "2026-01-20", "Shop", "expense", 900, "Laptop"))
        warns = " ".join(analytics.find_warnings(txs))
        self.assertIn("Unusual expense #9", warns)
        self.assertIn("Overspending", warns)


class ImportTests(unittest.TestCase):
    def test_sample_imports_cleanly(self):
        r = importer.import_csv(SAMPLE)
        self.assertEqual(r.errors, [])
        self.assertTrue(30 <= len(r.added) <= 50)

    def test_messy_file_reports_row_errors(self):
        r = importer.import_csv(MESSY)
        self.assertEqual(len(r.added), 4)           # grocery, blank-description default, alt date, one salary bonus
        self.assertEqual(r.duplicates, 1)
        self.assertGreaterEqual(len(r.errors), 7)
        self.assertFalse(r.fatal)

    def test_missing_file_and_columns(self):
        self.assertIn("not found", importer.import_csv("/nope.csv").fatal)
        with tempfile.NamedTemporaryFile("w", suffix=".csv", delete=False) as f:
            f.write("foo,bar\n1,2\n")
        self.assertIn("Missing required", importer.import_csv(f.name).fatal)

    def test_signed_amounts_without_type_column(self):
        with tempfile.NamedTemporaryFile("w", suffix=".csv", delete=False) as f:
            f.write("date,amount,memo\n2026-01-01,-20.50,Lunch\n2026-01-02,100,Gift\n")
        r = importer.import_csv(f.name)
        self.assertEqual([t.type for t in r.added], ["expense", "income"])


class ReportAndCliTests(unittest.TestCase):
    def test_exports(self):
        txs = importer.import_csv(SAMPLE).added
        for i, t in enumerate(txs, 1):
            t.id = i
        with tempfile.TemporaryDirectory() as d:
            paths = reports.export_all(txs, d)
            self.assertEqual(len(paths), 3)
            self.assertTrue(all(p.stat().st_size > 0 for p in paths))

    def test_cli_add_recovers_from_bad_input(self):
        with tempfile.TemporaryDirectory() as d:
            store = TransactionStore(Path(d) / "t.json"); store.load()
            answers = iter(["bad", "2026-05-01",       # date: bad then good
                            "x", "e",                   # type
                            "-5", "abc", "12.5",        # amount
                            "", "food",                 # category
                            "", "Lunch"])               # description
            out = []
            App(store, input_fn=lambda _p="": next(answers), output_fn=out.append).add()
            self.assertEqual(len(store.transactions), 1)
            self.assertEqual(store.transactions[0].amount, 12.5)
            self.assertGreaterEqual(sum("✗" in o for o in out), 6)


if __name__ == "__main__":
    unittest.main()
