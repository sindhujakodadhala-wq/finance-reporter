# Personal Finance CSV Reporter

A beginner-friendly, menu-driven Python app that loads transaction data from CSV,
validates it, stores it locally (JSON) and produces income/expense summaries,
warnings, exports and charts. Core app uses only the standard library;
`matplotlib` is needed only for charts.

## Quick start
```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt    # only needed for charts
python main.py                     # loads data/transactions.json (46 sample rows)
```
Optional: `python main.py --data my_data.json` to use a different data file,
`FINANCE_CURRENCY="₹"` to change the currency symbol, `NO_COLOR=1` to disable ANSI colour.

## Features (brief mapping)
| Requirement | Where |
|---|---|
| Interactive terminal menu | `finance/cli.py` |
| Defensive validation | `finance/validation.py` (dates, amounts, type, category, description; loop-until-valid prompts) |
| Load CSV + summarise | `finance/importer.py`, `finance/analytics.py` |
| JSON persistence (atomic writes, corruption recovery) | `finance/storage.py` |
| Keyword / category / type / date search | `analytics.search`, menu option 3 |
| Executive summary (totals, averages, status, trend) | `analytics.summarize`, `reports.render_summary` |
| Matplotlib charts (monthly bars, category pie, balance line) | `finance/plotting.py` |
| Export Markdown / TXT audit log / CSV | `finance/reports.py` |
| Threshold warnings (overspend, low savings, category share, anomalies, duplicates) | `analytics.find_warnings` |
| Bulk import with row-by-row error log | `importer.py` -> `data/import_errors.log` |

## CSV format for import
Required columns: `date`, `amount`. Optional: `description`, `category`, `type` (income/expense).
If `type` is missing, a negative amount = expense and positive = income.
Dates: `YYYY-MM-DD`, `DD/MM/YYYY`, `DD-MM-YYYY`. Delimiters `, ; tab` are auto-detected.

## Demo script (hackathon)
1. Launch `python main.py` - show banner and 46 loaded records.
2. Option **1**: enter a bad date (`bad`), negative amount (`-3`) -> validation re-prompts; then a valid entry.
3. Option **6**: import `data/messy_import_demo.csv` -> 4 valid, 7 errors listed, 1 duplicate skipped.
4. Option **4** and **5**: summary tables, trend, warnings (Rent share, laptop anomaly).
5. Option **8** / **7**: charts and reports appear in `reports/`.
6. Exit and relaunch -> new entries are still there (persistence).

## Tests
```bash
python -m unittest discover -s tests -v
```

## Project layout
```
main.py                 entry point
finance/                application package
data/                   sample CSV/JSON, messy import demo, live data file
scripts/make_sample_data.py   regenerates the sample data
tests/test_core.py      17 unit tests
reports/                generated charts/reports
```
Reset to sample data any time: `cp data/sample_transactions.json data/transactions.json`

## Ideas for next steps
Edit-transaction option, monthly budgets per category, Tkinter/Textual front-end, recurring transactions.
