#!/usr/bin/env python3
"""Entry point:  python main.py [--data PATH]"""
import argparse
import sys

from finance import config
from finance.cli import App
from finance.storage import TransactionStore


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Personal Finance CSV Reporter")
    parser.add_argument("--data", default=str(config.STORE_PATH), help="path to the JSON data file")
    args = parser.parse_args(argv)
    store = TransactionStore(args.data)
    store.load()
    App(store).run()
    return 0


if __name__ == "__main__":
    sys.exit(main())
